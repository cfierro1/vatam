<div id="top-nav-text">
	<?php echo do_shortcode( vamtam_get_option( 'top-bar-text' ) ) ?>
</div>

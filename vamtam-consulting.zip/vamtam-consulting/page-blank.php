<?php
/**
 * Single page template
 *
 * Template Name: Blank
 *
 * @package vamtam/consulting
 */

get_template_part( 'page' );

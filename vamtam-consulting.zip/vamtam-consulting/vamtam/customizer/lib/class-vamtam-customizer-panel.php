<?php

class Vamtam_Customizer_Panel extends WP_Customize_Panel {
	public $type = 'vamtam';
}

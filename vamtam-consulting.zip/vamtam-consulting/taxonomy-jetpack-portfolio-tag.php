<?php

get_template_part( 'archive', 'jetpack-portfolio' );

<?php
/**
 * Product Loop Start
 *
 * @author		WooThemes
 * @package	WooCommerce/Templates
 * @version     3.3.0
 */
?>
<ul class="products vamtam-wc columns-<?php echo esc_attr( wc_get_loop_prop( 'columns' ) ); ?>">
